<?php

$host="localhost:8080";
$dbname="socialdb";
$user="root";
$pass="";

$db=new pdo("mysql:host=$host;dbname=$dbname",$user,$pass);

?>