<ul class="sidebar-menu">
                  <li class="">
                      <a class="" href="">
                          <i class="icon-dashboard"></i>
                          <span>داشبورد</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-book"></i>
                          <span>مدیریت کاربران</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="javascript://" onclick="ajax('users/index.php','main-content');">لیست کاربران</a></li>
                          <li><a class="" href="buttons.html">ثبت نام</a></li>
                           <li><a class="" href="buttons.html">ویرایش کاربران</a></li>
                      </ul>
                  </li>
                  
                  
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-book"></i>
                          <span>امور مالی</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="mali/index.php" onclick="">مشاهده پرداختی های کاربران</a></li>
                          <li><a class="" href="mali/mojoodi.php">موجودی حساب کاربران</a></li>
                          <li><a class="" href="mali/paylinesetting.php">تنظیمات payline</a></li>
                      </ul>
                  </li>
                  
                  <li class="sub-menu active"></li>
                  <li>
                      <a class="" href="inbox.html">
                          <i class="icon-envelope"></i>
                          <span>مدیریت ایمیل ها </span>
                          <span class="label label-danger pull-right mail-info">2</span>
                      </a>
                  </li>
                  
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-book"></i>
                          <span>مدیریت پیامک ها</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="sms/sendsms.php" onclick="">ارسال پیامک</a></li>
                          <li><a class="" href="sms/index.php">پیامهای ارسالی کاربران</a></li>
                          <li><a class="" href="sms/report.php">گزارشات</a></li>
                      </ul>
                  </li>
                  
                  <li>
                      <a class="" href="">
                          <i class="icon-user"></i>
                          <span>خروج</span>
                      </a>
                  </li>
              </ul>