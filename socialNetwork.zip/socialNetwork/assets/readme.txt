
                                        ||--[]---[]---[]---[]---[]------[]--[]-||
                                        |					|
                                        |					|
                                        |  Copy Right By: 20 SCRIPT		|
                                        |					|
                                        |					|
                                        |  Web Site: WWW.20script.IR        	|
                                        |					|
                                        |					|
                                        |  Forum: www.20script.ir/forum	        |
                                        |					|
                                        |					|
                                        |  Shop: www.20script.ir/shop		|
                                        |					|
                                        |					|
                                        |  Yahoo ID: aka3_ir                    | 
                                        |                                       | 
                                        |  Email : aka3_ir@yahoo.com		|
                                        |	    		                |
                                        |					|
                                        |					|
                                        |					|
                                        ||--[]---[]---[]---[]---[]------[]--[]-||

